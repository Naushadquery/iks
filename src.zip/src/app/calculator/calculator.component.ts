import { Component, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit, OnChanges,OnDestroy {
  dt = new Date();
  password = 'naushad';
  Fruits = ["Apple","Orange","Grapes","Mango","Kiwi","Pomegranate"]; 
  calculator = "Normal Calculator"
  uname = '';
  defaultuname='Enter Name of User';
  num = 0;
  result = 0;
  displayNumber(){
    this.result = this.num;
  }
  constructor() {
    console.log("Object Created 1")
  }

  displayName(){
    this.uname=this.defaultuname;
  }
  displayTime():void{

    setInterval(()=>{
      this.dt = new Date();
    },1000);

  }
  ngOnInit(): void {
    console.log("Ng Init Init ");
    this.displayTime();
  }

  ngOnChanges(changes: SimpleChanges): void {
        console.log("Ng On Changes ");
  }
  ngOnDestroy(): void {
    console.log("Component destroyed");  
  }
}


