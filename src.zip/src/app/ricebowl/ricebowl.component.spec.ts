import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RicebowlComponent } from './ricebowl.component';

describe('RicebowlComponent', () => {
  let component: RicebowlComponent;
  let fixture: ComponentFixture<RicebowlComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RicebowlComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RicebowlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
