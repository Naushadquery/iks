import { Component } from '@angular/core';

@Component({
  selector: 'app-ricebowl',
  templateUrl: './ricebowl.component.html',
  styleUrls: ['./ricebowl.component.css']
})
export class RicebowlComponent {

  rice = 'Jeera Rice';

}
